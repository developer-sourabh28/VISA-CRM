export default function Payments() {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-10">
        <h1 className="text-3xl font-semibold mb-4">Payments Page</h1>
        <p className="text-gray-600 dark:text-gray-300 text-lg">
          💳 This page is under construction. Payment features will be available soon!
        </p>
      </div>
    );
  }
  