import { useState, useEffect } from 'react';
import { useParams, Link, useLocation } from 'wouter';
import {
  Calendar,
  Mail,
  Phone,
  MapPin,
  Globe,
  CreditCard,
  User,
  FileText,
  Clock,
  ChevronRight,
  Plus,
  ArrowLeft,
  Send,
  CircleUser
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { getVisaTracker } from '../lib/api';
import { getClient, getClientAppointments } from '../lib/api';
import { useToast } from '../components/ui/use-toast.js';
import VisaApplicationTracker from "../components/VisaApplicationTracker"

function ClientProfile() {
  const [location, setLocation] = useLocation();
  const { id } = useParams();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('history');

  // Extract client ID from URL
  const clientId = location.split('/').pop();
  console.log('Current location:', location);
  console.log('Extracted client ID:', clientId);
  console.log('useParams ID:', id);

  // Fetch client data
  const {
    data: clientResponse,
    isLoading: clientLoading,
    error: clientError
  } = useQuery({
    queryKey: ['client', clientId],
    queryFn: async () => {
      if (!clientId) {
        console.error('No client ID provided');
        throw new Error('Client ID is required');
      }
      console.log('Making API request for client ID:', clientId);
      try {
        const response = await getClient(clientId);
        console.log('Raw API Response:', response);
        return response;
      } catch (error) {
        console.error('Error fetching client:', error);
        throw error;
      }
    },
    enabled: !!clientId,
    retry: false
  });

  // Get client data from the response
  const client = clientResponse?.data?.data || clientResponse?.data;
  
  console.log('Client Response:', clientResponse);
  console.log('Client Data:', client);

  // Fetch visa tracker data
  const {
    data: visaTrackerResponse,
    isLoading: visaTrackerLoading,
    error: visaTrackerError
  } = useQuery({
    queryKey: ['visaTracker', client?._id],
    queryFn: async () => {
      if (!client?._id) {
        throw new Error('Client ID is required');
      }
      console.log('Fetching visa tracker for client:', client._id);
      try {
        const response = await getVisaTracker(client._id);
        console.log('Visa tracker response:', response);
        return response;
      } catch (error) {
        console.error('Error fetching visa tracker:', error);
        throw error;
      }
    },
    enabled: !!client?._id,
    retry: false
  });

  // Get visa tracker data from the response
  const visaTracker = visaTrackerResponse?.data?.data || visaTrackerResponse?.data;

  // Fetch client activities/history
  const {
    data: activitiesResponse,
    isLoading: activitiesLoading,
    error: activitiesError
  } = useQuery({
    queryKey: ['clientAppointments', clientId],
    queryFn: () => getClientAppointments(clientId),
    enabled: !!clientId && !!client,
    retry: false
  });

  // Get activities data from the response
  const activities = activitiesResponse?.data;

  useEffect(() => {
    if (clientError) {
      console.error('Client Error:', clientError);
      toast({
        title: "Error loading client",
        description: clientError.message || "Could not load client data. Please try again.",
        variant: "destructive"
      });
    }
  }, [clientError, toast]);

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const date = new Date(dateString);
    return date.toLocaleDateString();
  };

  if (clientLoading) {
    return (
      <div className="container mx-auto px-4 py-10">
        <div className="text-center">Loading client profile...</div>
      </div>
    );
  }

  if (!client && !clientLoading) {
    return (
      <div className="container mx-auto px-4 py-10">
        <div className="text-center">
          <h2 className="text-xl font-medium">Client not found</h2>
          <p className="mt-2 text-gray-600">The client you're looking for doesn't exist or you may not have permission to view it.</p>
          <Link href="/clients">
            <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
              Return to Clients
            </button>
          </Link>
        </div>
      </div>
    );
  }

  // Convert client status to badge color
  const getStatusBadgeClass = (status) => {
    switch (status) {
      case "Completed":
        return "bg-green-100 text-green-800";
      case "Active":
        return "bg-blue-100 text-blue-800";
      case "In Progress":
        return "bg-purple-100 text-purple-800";
      case "Hold":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Top Header Area */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 pt-4 pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-500">
                  <CircleUser size={24} />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl font-medium">{client.firstName} {client.lastName}</h1>
                  <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getStatusBadgeClass(client.status)}`}>
                    {client.status || "Active"}
                  </span>
                </div>
                <div className="text-sm text-gray-500">{client.visaType || "No Visa Type"}</div>
                <div className="mt-1 text-xs text-gray-500">
                  Updated: {formatDate(client.updatedAt)}
                </div>
              </div>
            </div>
          </div>

          {/* Client Details Row */}
          <div className="grid grid-cols-4 gap-8 mt-6">
            <div>
              <div className="text-xs text-gray-500 mb-1">Assigned Consultant</div>
              <div className="text-sm font-medium">
                {client.assignedConsultant || "Not Assigned"}
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-1">Application ID</div>
              <div className="text-sm font-medium">
                {client._id ? client._id.substring(0, 8) : "—"}
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-1">Country</div>
              <div className="text-sm font-medium">
                {client.address?.country || "—"}
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500 mb-1">Timeline</div>
              <div className="text-sm font-medium">
                Started: {formatDate(client.createdAt)}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mt-6">
            <button className="px-3 py-2 text-sm border border-gray-300 bg-white rounded-md hover:bg-gray-50 inline-flex items-center gap-2">
              <Plus size={16} /> Add Task
            </button>
            <button className="px-3 py-2 text-sm border border-gray-300 bg-white rounded-md hover:bg-gray-50 inline-flex items-center gap-2">
              <Send size={16} /> Send Email
            </button>
            <button className="px-3 py-2 text-sm border border-gray-300 bg-white rounded-md hover:bg-gray-50 inline-flex items-center gap-2">
              <Clock size={16} /> Update Status
            </button>
            <button
              className={`px-4 py-3 text-sm font-medium ${activeTab === 'visaTracker' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
              onClick={() => setActiveTab('visaTracker')}
            >
              <div className="flex items-center gap-2">
                <MapPin size={16} />
                Visa Tracker
              </div>
            </button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        {/* Main content area with tabs */}
        <div className="bg-white rounded-lg shadow mb-6">
          {/* Tabs navigation */}
          <div className="border-b">
            <nav className="flex">
              <button
                className={`px-4 py-3 text-sm font-medium ${activeTab === 'history' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                onClick={() => setActiveTab('history')}
              >
                <div className="flex items-center gap-2">
                  <Clock size={16} />
                  History
                </div>
              </button>
              <button
                className={`px-4 py-3 text-sm font-medium ${activeTab === 'payments' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                onClick={() => setActiveTab('payments')}
              >
                <div className="flex items-center gap-2">
                  <CreditCard size={16} />
                  Payments
                </div>
              </button>
              <button
                className={`px-4 py-3 text-sm font-medium ${activeTab === 'documents' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                onClick={() => setActiveTab('documents')}
              >
                <div className="flex items-center gap-2">
                  <FileText size={16} />
                  Documents
                </div>
              </button>
              <button
                className={`px-4 py-3 text-sm font-medium ${activeTab === 'notes' ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                onClick={() => setActiveTab('notes')}
              >
                <div className="flex items-center gap-2">
                  <FileText size={16} />
                  Notes
                </div>
              </button>
            </nav>
          </div>

          {/* Tab content */}
          <div className="p-4">
            {activeTab === 'history' && (
              <div>
                <table className="w-full">
                  <thead>
                    <tr className="text-left text-xs text-gray-500 border-b">
                      <th className="pb-2 font-medium">Date</th>
                      <th className="pb-2 font-medium">Activity</th>
                      <th className="pb-2 font-medium">Status</th>
                      <th className="pb-2 font-medium">Assigned To</th>
                      <th className="pb-2 font-medium text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {activities?.map((activity, index) => (
                      <tr key={index} className="border-b">
                        <td className="py-3 pr-4">
                          <div className="text-sm">{formatDate(activity.date)}</div>
                        </td>
                        <td className="py-3 pr-4">
                          <div className="text-sm font-medium">{activity.type}</div>
                        </td>
                        <td className="py-3 pr-4">
                          <span className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${getStatusBadgeClass(activity.status)}`}>
                            {activity.status}
                          </span>
                        </td>
                        <td className="py-3 pr-4">
                          <div className="text-sm">{activity.assignedTo || "—"}</div>
                        </td>
                        <td className="py-3 text-right">
                          <button className="text-blue-600 hover:underline text-xs flex items-center gap-1 ml-auto">
                            View Details <ChevronRight size={12} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === 'payments' && (
              <div className="text-center py-6 text-gray-500">
                Payment history will be displayed here.
              </div>
            )}

            {activeTab === 'documents' && (
              <div className="text-center py-6 text-gray-500">
                Client's documents will be displayed here.
              </div>
            )}

            {activeTab === 'notes' && (
              <div className="text-center py-6 text-gray-500">
                Client notes will be displayed here.
              </div>
            )}

            {activeTab === 'visaTracker' && (
              <div className="p-4">
                {visaTrackerLoading ? (
                  <div className="text-center py-6 text-gray-500">
                    Loading visa tracker data...
                  </div>
                ) : visaTrackerError ? (
                  <div className="text-center py-6 text-red-500">
                    Error loading visa tracker: {visaTrackerError.message}
                  </div>
                ) : client ? (
                  <VisaApplicationTracker client={client} />
                ) : (
                  <div className="text-center py-6 text-gray-500">
                    No client data available.
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default ClientProfile;